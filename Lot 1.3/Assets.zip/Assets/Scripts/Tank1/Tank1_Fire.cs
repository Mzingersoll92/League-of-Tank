﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank1_Fire : MonoBehaviour {

    public float bulletForce = 500.0f;

    void OnTriggerEnter2D (Collider2D target)
    {
        if (target.gameObject.tag == "FirePoint") GetComponent<Rigidbody2D>().AddForce(transform.right * bulletForce);
    }

}
