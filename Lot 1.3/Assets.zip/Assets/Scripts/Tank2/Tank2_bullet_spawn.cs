﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank2_bullet_spawn : MonoBehaviour {

    public KeyCode fire;
    public GameObject bullet;
    public Transform spawnPoint;

    void FixedUpdate()
    {
        bool shoot = Input.GetKey(fire);

        if (shoot) Instantiate(bullet, spawnPoint.position, spawnPoint.rotation);
    }
}
